package com.ps20682;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ps20682lsbs5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
