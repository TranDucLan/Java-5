package com.ps20682.controller;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ps20682.dao.CategoryDAO;
import com.ps20682.entity.Category;

@Controller
public class CategoryController1 {
	@Autowired
	EntityManager em;
	
	@ResponseBody
	@RequestMapping("/category/list1")
	public List<Category> list1(){
		SimpleJpaRepository<Category, String > repo = new SimpleJpaRepository<>(Category.class, em);
		return repo.findAll();	
	}
		
	@Autowired
	CategoryDAO repo;
	@ResponseBody
	@RequestMapping("/category/list2")
	public List<Category> list2(){
		return repo.findAll();
	}

	
	@Autowired
	CategoryDAO repo2;
	@RequestMapping("/category/list3")
	public String list3(Model model) {
		List<Category> items = repo2.findAll();
		model.addAttribute("items", items);
		return "category/list";
	}
	
}
