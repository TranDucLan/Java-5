package com.ps20682;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ps20682lsbs5Application {

	public static void main(String[] args) {
		SpringApplication.run(ps20682lsbs5Application.class, args);
	}

}
