package baove.dao;

import org.springframework.data.jpa.repository.JpaRepository;


import baove.entity.NhanVien;



public interface NhanVienDAO extends JpaRepository<NhanVien, String>{
	//.....
}
