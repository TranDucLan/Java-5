package baove;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Baovejava5Application {

	public static void main(String[] args) {
		SpringApplication.run(Baovejava5Application.class, args);
	}

}
