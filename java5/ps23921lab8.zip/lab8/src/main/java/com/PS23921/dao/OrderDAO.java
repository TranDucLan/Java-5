package com.PS23921.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PS23921.entity.Order;



public interface OrderDAO extends JpaRepository<Order, Long>{
}
