package com.PS23921.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.PS23921.entity.OrderDetail;



public interface OrderDetailDAO extends JpaRepository<OrderDetail, Long>{
}