package PS20682Lab6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps20682Lab6Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps20682Lab6Application.class, args);
	}

}
