package PS21307Lab6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps23917Lab6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
