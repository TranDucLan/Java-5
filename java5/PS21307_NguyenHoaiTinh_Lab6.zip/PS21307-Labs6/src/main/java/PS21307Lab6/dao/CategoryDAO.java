package PS21307Lab6.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import PS21307Lab6.entity.Category;






public interface CategoryDAO extends JpaRepository<Category, String>{
}
