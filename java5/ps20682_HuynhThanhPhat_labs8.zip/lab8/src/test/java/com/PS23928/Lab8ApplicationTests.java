package com.PS23928;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
